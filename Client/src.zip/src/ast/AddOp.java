package ast;

public class AddOp extends Operator {

	public AddOp(String op) {
		super(op);
		// TODO Auto-generated constructor stub
	}
		

}
