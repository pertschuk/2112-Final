package ast;

public class MulOp extends Operator {

	public MulOp(String op) {
		super(op);
		// TODO Auto-generated constructor stub
	}


}
