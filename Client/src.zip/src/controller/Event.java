package controller;

public interface Event {
	
}
