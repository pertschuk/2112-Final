package ast;

/**
 * 
 * ----
 * Class represents an Operator, eg >, <
 * @author jack
 *
 */
public class RelOp extends Operator {

	public RelOp(String op) {
		super(op);
		// TODO Auto-generated constructor stub
	}
	

}
