package parse;

enum TokenCategory {
    ACTION, RELOP, ADDOP, MULOP, SENSOR, MEMSUGAR, OTHER;
}
